const String apiUrl = "https://example.com/api"; // Replace with your API URL
